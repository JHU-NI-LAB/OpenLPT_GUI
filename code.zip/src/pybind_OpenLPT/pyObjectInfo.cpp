
void init_ObjectInfo(py::module &m) 
{
    py::class_<Object2D>(m, "Object2D")
        .def(py::init<>())
        .def(py::init<Object2D const&>())
        .def(py::init<Pt2D const&>())
        .def_readwrite("_pt_center", &Object2D::_pt_center)
        .def("to_dict", [](Object2D const& self){
            return py::dict(
                "_pt_center"_a=self._pt_center
            );
        })
        .doc() = "Object2D class";

    py::class_<Tracer2D, Object2D>(m, "Tracer2D")
        .def(py::init<>())
        .def(py::init<Tracer2D const&>())
        .def(py::init<Pt2D const&>())
        .def_readwrite("_r_px", &Tracer2D::_r_px)
        .def("to_dict", [](Tracer2D const& self){
            return py::dict(
                "_pt_center"_a=self._pt_center, 
                "_r_px"_a=self._r_px
            );
        })
        .doc() = "Tracer2D class";
    
    py::class_<Bubble2D, Object2D>(m, "Bubble2D")
        .def(py::init<>())
        .def(py::init<Bubble2D const&>())
        .def(py::init<Pt2D const&, double&>())
        .def_readwrite("_r_px", &Bubble2D::_r_px)
        .def("to_dict", [](Bubble2D const& self){
            return py::dict(
                "_pt_center"_a=self._pt_center, 
                "_r_px"_a=self._r_px
            );
        })
        .doc() = "Bubble2D class";

    py::class_<Object3D>(m, "Object3D")
        .def(py::init<>())
        .def(py::init<Object3D const&>())
        .def(py::init<Pt3D const&>())
        .def_readwrite("_pt_center", &Object3D::_pt_center)
        .def_readwrite("_is_tracked", &Object3D::_is_tracked)
        .def("to_dict", [](Object3D const& self){
            return py::dict(
                "_pt_center"_a=self._pt_center, 
                "_is_tracked"_a=self._is_tracked
            );
        })
        .doc() = "Object3D class";

    py::class_<Tracer3D, Object3D>(m, "Tracer3D")
        .def(py::init<>())
        .def(py::init<Tracer3D const&>())
        .def(py::init<Pt3D const&>())
        .def_readwrite("_n_2d", &Tracer3D::_n_2d)
        .def_readwrite("_error", &Tracer3D::_error)
        .def_readwrite("_camid_list", &Tracer3D::_camid_list)
        .def_readwrite("_tr2d_list", &Tracer3D::_tr2d_list)
        .def("addTracer2D", [](Tracer3D& self, Tracer2D const& tracer2d, int cam_id){
            self.addTracer2D(tracer2d, cam_id);
        })
        .def("addTracer2D", [](Tracer3D& self, std::vector<Tracer2D> const& tracer2d_list, std::vector<int> const& camid_list){
            self.addTracer2D(tracer2d_list, camid_list);
        })
        .def("removeTracer2D", [](Tracer3D& self, int cam_id){
            self.removeTracer2D(cam_id);
        })
        .def("removeTracer2D", [](Tracer3D& self, std::vector<int> const& camid_list){
            self.removeTracer2D(camid_list);
        })
        .def("clearTracer2D", &Tracer3D::clearTracer2D)
        .def("updateTracer2D", [](Tracer3D& self, Tracer2D const& tracer2d, int cam_id){
            self.updateTracer2D(tracer2d, cam_id);
        })
        .def("updateTracer2D", [](Tracer3D& self, std::vector<Tracer2D> const& tracer2d_list, std::vector<int> const& camid_list){
            self.updateTracer2D(tracer2d_list, camid_list);
        })
        .def("projectObject2D", &Tracer3D::projectObject2D)
        .def("getTracer2D", [](Tracer3D& self, int cam_id){
            Tracer2D tracer2d;
            self.getTracer2D(tracer2d, cam_id);
            return tracer2d;
        })
        .def("saveObject3D", [](Tracer3D& self, std::string& file, int n_cam_all, bool is_append=true){
            std::ofstream output(file, is_append ? std::ios::app : std::ios::out);
            self.saveObject3D(output, n_cam_all);
        }, py::arg("file"), py::arg("n_cam_all"), py::arg("is_append")=true)
        .def("to_dict", [](Tracer3D const& self){
            return py::dict(
                "_pt_center"_a=self._pt_center, 
                "_is_tracked"_a=self._is_tracked, 
                "_n_2d"_a=self._n_2d, 
                "_error"_a=self._error, 
                "_camid_list"_a=self._camid_list, 
                "_tr2d_list"_a=self._tr2d_list
            );
        })
        .doc() = "Tracer3D class";

    py::class_<Bubble3D, Object3D>(m, "Bubble3D")
        .def(py::init<>())
        .def(py::init<Bubble3D const&>())
        .def(py::init<Pt3D const&>())
        .def_readwrite("_n_2d", &Bubble3D::_n_2d)
        .def_readwrite("_error", &Bubble3D::_error)
        .def_readwrite("_camid_list", &Bubble3D::_camid_list)
        .def_readwrite("_bb2d_list", &Bubble3D::_bb2d_list)
        .def_readwrite("_r3d", &Bubble3D::_r3d)
        .def("addBubble2D", [](Bubble3D& self, Bubble2D const& bb2d, int cam_id){
            self.addBubble2D(bb2d, cam_id);
        })
        .def("addBubble2D", [](Bubble3D& self, std::vector<Bubble2D> const& bb2d_list, std::vector<int> const& camid_list){
            self.addBubble2D(bb2d_list, camid_list);
        })
        .def("removeBubble2D", [](Bubble3D& self, int cam_id){
            self.removeBubble2D(cam_id);
        })
        .def("removeBubble2D", [](Bubble3D& self, std::vector<int> const& camid_list){
            self.removeBubble2D(camid_list);
        })
        .def("clearBubble2D", &Bubble3D::clearBubble2D)
        .def("updateBubble2D", [](Bubble3D& self, Bubble2D const& bb2d, int cam_id){
            self.updateBubble2D(bb2d, cam_id);
        })
        .def("updateBubble2D", [](Bubble3D& self, std::vector<Bubble2D> const& bb2d_list, std::vector<int> const& camid_list){
            self.updateBubble2D(bb2d_list, camid_list);
        })
        .def("projectObject2D", &Bubble3D::projectObject2D)
        .def("setRadius2D", &Bubble3D::setRadius2D)
        .def("getBubble2D", [](Bubble3D& self, int cam_id){
            Bubble2D bb2d;
            self.getBubble2D(bb2d, cam_id);
            return bb2d;
        })
        .def("updateR3D", [](Bubble3D& self, std::vector<Camera> const& cam_list_all, double ratio_thres, double tol3d){
            return self.updateR3D(cam_list_all, ratio_thres, tol3d);
        }, py::arg("cam_list_all"), py::arg("ratio_thres")=0.05, py::arg("tol3d")=100)
        .def("updateR2D", [](Bubble3D& self, int cam_id, std::vector<Camera> const& cam_list_all){
            self.updateR2D(cam_id, cam_list_all);
        })
        .def("updateR2D", [](Bubble3D& self, std::vector<Camera> const& cam_list_all){
            self.updateR2D(cam_list_all);
        })
        .def("saveObject3D", [](Bubble3D& self, std::string& file, int n_cam_all, bool is_append=true){
            std::ofstream output(file, is_append ? std::ios::app : std::ios::out);
            self.saveObject3D(output, n_cam_all);
        }, py::arg("file"), py::arg("n_cam_all"), py::arg("is_append")=true)
        .def("to_dict", [](Bubble3D const& self){
            return py::dict(
                "_pt_center"_a=self._pt_center, 
                "_is_tracked"_a=self._is_tracked, 
                "_n_2d"_a=self._n_2d, 
                "_error"_a=self._error, 
                "_camid_list"_a=self._camid_list, 
                "_bb2d_list"_a=self._bb2d_list
            );
        })
        .doc() = "Bubble3D class";
}
