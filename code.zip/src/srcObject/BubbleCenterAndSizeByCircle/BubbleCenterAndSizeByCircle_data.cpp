//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// BubbleCenterAndSizeByCircle_data.cpp
//
// Code generation for function 'BubbleCenterAndSizeByCircle_data'
//

// Include files
#include "BubbleCenterAndSizeByCircle_data.h"
#include "rt_nonfinite.h"

// Variable Definitions
omp_nest_lock_t emlrtNestLockGlobal;

// End of code generation (BubbleCenterAndSizeByCircle_data.cpp)
