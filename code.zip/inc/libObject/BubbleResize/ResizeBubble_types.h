//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// ResizeBubble_types.h
//
// Code generation for function 'ResizeBubble'
//

#ifndef RESIZEBUBBLE_TYPES_H
#define RESIZEBUBBLE_TYPES_H

// Include files
#include "rtwtypes.h"
#define MAX_THREADS omp_get_max_threads()

#endif
// End of code generation (ResizeBubble_types.h)
