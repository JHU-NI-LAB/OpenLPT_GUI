//
//	ObjectInfo.h 
//
//	Base class for various image formats
//	All image format types should inherit from Image 
//
//	Created by Shijie Zhong 07/11/2022 
//

#ifndef OBJECTINFO_H
#define OBJECTINFO_H 

#include <vector>
#include "Matrix.h"
#include "Camera.h"
#include "STBCommons.h"

// 2D object classes
class Object2D
{
public:
    Pt2D _pt_center; 

    Object2D () {};
    Object2D (Object2D const& object) : _pt_center(object._pt_center) {};
    Object2D (Pt2D const& pt_center) : _pt_center(pt_center) {};
    virtual ~Object2D () {};
};

class Tracer2D : public Object2D
{
public:
    double _r_px = 2; // [px], for shaking

    Tracer2D () {};
    Tracer2D (Tracer2D const& tracer) : Object2D(tracer), _r_px(tracer._r_px) {};
    Tracer2D (Pt2D const& pt_center) : Object2D(pt_center) {};
    ~Tracer2D () {};
};

class Bubble2D : public Object2D 
{
public:
    double _r_px = 2; // [px], for shaking

    Bubble2D () {};
    Bubble2D (Bubble2D const& bubble) : Object2D(bubble), _r_px(bubble._r_px) {};
    Bubble2D (Pt2D const& pt_center, double r_px) : Object2D(pt_center), _r_px(r_px) {};
    ~Bubble2D () {};
};

// 3D object classes
class Object3D
{
public:
    Pt3D _pt_center; 
    bool _is_tracked = false;

    Object3D () {};
    Object3D (Object3D const& object) : _pt_center(object._pt_center) {};
    Object3D (Pt3D const& pt_center) : _pt_center(pt_center) {};
    void saveObject3D (std::ofstream& output, int n_cam_all) const {};
    void projectObject2D (std::vector<int> const& camid_list, std::vector<Camera> const& cam_list_all) {};
    ~Object3D () {};
};

class Tracer3D : public Object3D
{
public:
    int _n_2d = 0;
    double _error = 0; // [mm]
    double _r2d_px = 2; // [px], for shaking
    std::vector<int> _camid_list; // min id = 0
    std::vector<Tracer2D> _tr2d_list;

    Tracer3D () {};
    Tracer3D (Tracer3D const& tracer3d) : Object3D(tracer3d), _n_2d(tracer3d._n_2d), _error(tracer3d._error), _r2d_px(tracer3d._r2d_px), _camid_list(tracer3d._camid_list), _tr2d_list(tracer3d._tr2d_list) {};
    Tracer3D (Pt3D const& pt_center) : Object3D(pt_center) {};
    ~Tracer3D () {};

    // user has to make sure the cam_id is unique
    void addTracer2D (Tracer2D const& tracer2d, int cam_id);
    void addTracer2D (std::vector<Tracer2D> const& tracer2d_list, std::vector<int> const& camid_list);

    void removeTracer2D (int cam_id);
    void removeTracer2D (std::vector<int> const& camid_list);
    void clearTracer2D ();
    
    void updateTracer2D (Tracer2D const& tracer2d, int cam_id);

    // _tr2d_list and _camid_list will be updated to tracer2d_list and camid_list
    void updateTracer2D (std::vector<Tracer2D> const& tracer2d_list, std::vector<int> const& camid_list);

    // project 3D tracer to 2D
    // It will project the 3D tracer to 2D for each camera in camid_list
    //  and store the 2D tracers in _tr2d_list.
    // input:
    //  camid_list: camera id list (set _camid_list = camid_list)
    //  cam_list_all: all camera parameters, camid = 0, 1, 2, ...
    void projectObject2D (std::vector<int> const& camid_list, std::vector<Camera> const& cam_list_all);

    void getTracer2D (Tracer2D& tracer2d, int cam_id);

    // save the 3D tracer to a file
    void saveObject3D (std::ofstream& output, int n_cam_all) const;
};

// Bubble3D class
class Bubble3D : public Object3D
{
public:
    int _n_2d = 0;
    double _error = 0; // [mm]
    double _r3d = -1; // [mm]
    std::vector<int> _camid_list; // min id = 0
    std::vector<Bubble2D> _bb2d_list;

    Bubble3D () {};
    Bubble3D (Bubble3D const& bubble3d) : Object3D(bubble3d), _n_2d(bubble3d._n_2d), _error(bubble3d._error), _r3d(bubble3d._r3d), _camid_list(bubble3d._camid_list), _bb2d_list(bubble3d._bb2d_list) {};
    Bubble3D (Pt3D const& pt_center) : Object3D(pt_center) {};
    ~Bubble3D () {};

    // user has to make sure the cam_id is unique
    void addBubble2D (Bubble2D const& bb2d, int cam_id);
    void addBubble2D (std::vector<Bubble2D> const& bb2d_list, std::vector<int> const& camid_list);

    void removeBubble2D (int cam_id);
    void removeBubble2D (std::vector<int> const& camid_list);
    void clearBubble2D ();

    void updateBubble2D (Bubble2D const& bb2d, int cam_id);

    // _bb2d_list and _camid_list will be updated to bubble2d_list and camid_list
    void updateBubble2D (std::vector<Bubble2D> const& bb2d_list, std::vector<int> const& camid_list);

    // project 3D bubble to 2D
    // It will project the 3D bubble to 2D for each camera in camid_list
    //  and store the 2D bubbles in _bb2d_list.
    // input:
    //  camid_list: camera id list (set _camid_list = camid_list)
    //  cam_list_all: all camera parameters, camid = 0, 1, 2, ...
    void projectObject2D (std::vector<int> const& camid_list, std::vector<Camera> const& cam_list_all);
    void setRadius2D (std::vector<double> r_px_list);

    void getBubble2D (Bubble2D& bubble2d, int cam_id);

    // update 3D bubble radius
    bool updateR3D (std::vector<Camera> const& cam_list_all, double ratio_thres = 0.05, double tol3d = 100);

    // update 2D bubble radius
    void updateR2D (int cam_id, std::vector<Camera> const& cam_list_all);
    void updateR2D (std::vector<Camera> const& cam_list_all);

    // save the 3D bubble to a file
    void saveObject3D (std::ofstream& output, int n_cam_all) const;
};

// Define Obj3dCloud class for KD-tree
template <class T3D>
struct Obj3dCloud
{
    std::vector<T3D> const& _obj3d_list;  // 3D points
    Obj3dCloud(std::vector<T3D> const& obj3d_list) : _obj3d_list(obj3d_list) {}

    // Must define the interface required by nanoflann
    inline size_t kdtree_get_point_count() const { return _obj3d_list.size(); }
    inline float kdtree_get_pt(const size_t idx, int dim) const { return _obj3d_list[idx]._pt_center[dim]; }

    // Bounding box (not needed for standard KD-tree queries)
    template <class BBOX> bool kdtree_get_bbox(BBOX&) const { return false; }
};

#endif
