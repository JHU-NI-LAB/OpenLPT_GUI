//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// BubbleCenterAndSizeByCircle_data.h
//
// Code generation for function 'BubbleCenterAndSizeByCircle_data'
//

#ifndef BUBBLECENTERANDSIZEBYCIRCLE_DATA_H
#define BUBBLECENTERANDSIZEBYCIRCLE_DATA_H

// Include files
#include "rtwtypes.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Variable Declarations
extern omp_nest_lock_t emlrtNestLockGlobal;

#endif
// End of code generation (BubbleCenterAndSizeByCircle_data.h)
